﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace LibrarySystemKendoMVC.Models
{
    public class Category
    {

        [ScaffoldColumn(false)]
        public int Id { get; set; }
        [Required]
        [MinLength(5, ErrorMessage="Title must be five-letter word atleast.")]
        public string Title { get; set; }
    }
}