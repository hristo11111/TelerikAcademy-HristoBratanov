﻿using LibrarySystemKendoMVC.Models;
using LibrarySystemKendoMVC.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LibrarySystemKendoMVC.Controllers
{
    public class CategoriesController : Controller
    {
        //
        // GET: /Categories/
        public ActionResult Index(int? id)
        {
            ApplicationDbContext db = new ApplicationDbContext();

            if (id != null)
            {
                var cat = db.Categories.FirstOrDefault(c => c.Id == id);
                return PartialView("_EditCategoryForm", cat);
            }

            return View();
        }

        public JsonResult GetAllCategories()
        {
            ApplicationDbContext db = new ApplicationDbContext();
            var categories = db.Categories.ToList();

            return Json(categories, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SaveEdit(EditCategoryViewModel model)
        {
            //TODO:
            ApplicationDbContext db = new ApplicationDbContext();
            var category = db.Categories.FirstOrDefault(c => c.Id == model.Id);
            category.Title = model.Title;
            db.SaveChanges();

            return View();
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return View("Index");
            }
            else
            {
                ApplicationDbContext db = new ApplicationDbContext();
                var category = db.Categories.FirstOrDefault(c => c.Id == id);

                return View(category);
            }
        }

    }
}