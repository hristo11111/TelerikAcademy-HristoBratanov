﻿using Kendo.Mvc.UI;
using LibrarySystemKendoMVC.Models;
using LibrarySystemKendoMVC.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LibrarySystemKendoMVC.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ApplicationDbContext db = new ApplicationDbContext();

            var result = db.Categories.ToList().Select(x => new TreeViewItemModel
            {
                Text = x.Title,
                Items = db.Books.Where(b => b.Category.Title == x.Title)
                .Select(y => new TreeViewItemModel
                {
                    Text = y.Title
                })
                    .ToList()
            });

            var books = db.Books;

            TreeViewBookCommonViewModel model = new TreeViewBookCommonViewModel();
            model.TreeView = result;
            model.Books = books;

            return View(model);
        }

        public ActionResult GetSingleBook(string title)
        {
            ApplicationDbContext db = new ApplicationDbContext();
            Book book = db.Books.FirstOrDefault(b => b.Title == title);
            return View(book);
        }

        public ActionResult GetSearchBook(string title)
        {
            ApplicationDbContext db = new ApplicationDbContext();
            var book = db.Books.Where(b => b.Title.Contains(title));
            return View(book);
        }

        //public ActionResult AutoComplete()
        //{
        //    ApplicationDbContext db = new ApplicationDbContext();
        //    var books = db.Books;

        //    return View(books);
        //}
    }
}