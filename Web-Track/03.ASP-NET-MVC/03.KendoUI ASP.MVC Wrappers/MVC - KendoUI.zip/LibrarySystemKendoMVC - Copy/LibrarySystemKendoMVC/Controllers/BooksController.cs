﻿using LibrarySystemKendoMVC.Models;
using LibrarySystemKendoMVC.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LibrarySystemKendoMVC.Controllers
{
    public class BooksController : Controller
    {
        //
        // GET: /Books/
        public ActionResult Index()
        {
            ApplicationDbContext db = new ApplicationDbContext();
            var books = db.Books;
            return View(books);
        }

        public JsonResult GetAllBooks()
        {
            ApplicationDbContext db = new ApplicationDbContext();
            var books = db.Books;
            return Json(books, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Edit(int id)
        {
            ApplicationDbContext db = new ApplicationDbContext();
            var book = db.Books.FirstOrDefault(b => b.Id == id);
            return View(book);
        }

        public ActionResult Delete(int id)
        {
            ApplicationDbContext db = new ApplicationDbContext();
            var book = db.Books.FirstOrDefault(b => b.Id == id);
            return View(book);
        }

        public ActionResult DeleteConfirmed(int id)
        {
            ApplicationDbContext db = new ApplicationDbContext();
            var book = db.Books.FirstOrDefault(b => b.Id == id);
            db.Books.Remove(book);
            db.SaveChanges();
            return View();
        }

        public ActionResult SaveEdit(EditBookViewModel model)
        {
            ApplicationDbContext db = new ApplicationDbContext();
            var cat = db.Categories.FirstOrDefault(c => c.Id == model.Category);

            var book = db.Books.FirstOrDefault(b => b.Id == model.Id);
            book.Title = model.Title;
            book.PublishDate = model.PublishDate;
            book.Description = model.Description;
            book.Author = model.Author;
            book.Category = cat;
            db.SaveChanges();
            return View();
        }
	}
}