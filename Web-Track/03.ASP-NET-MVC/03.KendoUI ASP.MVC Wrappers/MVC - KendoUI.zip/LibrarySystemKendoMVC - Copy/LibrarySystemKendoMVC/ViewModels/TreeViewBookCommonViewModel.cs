﻿using LibrarySystemKendoMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LibrarySystemKendoMVC.ViewModels
{
    public class TreeViewBookCommonViewModel
    {
        public IEnumerable<Kendo.Mvc.UI.TreeViewItemModel> TreeView { get; set; }
        public IEnumerable<Book> Books { get; set; }
    }
}