﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(LibrarySystemKendoMVC.Startup))]
namespace LibrarySystemKendoMVC
{
    public partial class Startup 
    {
        public void Configuration(IAppBuilder app) 
        {
            ConfigureAuth(app);
        }
    }
}
